package com.shamil.msulearningapi.repository;

import com.shamil.msulearningapi.model.Announcement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {

}
