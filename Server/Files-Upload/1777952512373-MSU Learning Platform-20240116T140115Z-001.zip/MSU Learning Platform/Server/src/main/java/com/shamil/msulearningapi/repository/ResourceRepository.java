package com.shamil.msulearningapi.repository;

import com.shamil.msulearningapi.model.Resources;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResourceRepository extends JpaRepository<Resources, Long> {
}
