package com.shamil.msulearningapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsuLearningApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
